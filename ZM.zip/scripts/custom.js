$(document).ready(function() {
	$(".owl-carousel").owlCarousel({
		loop:true,
		items: 1,
		margin:130,
		animateIn: 'fadeIn',
		animateOut: 'fadeOut',
		stagePadding: 30
	});
});